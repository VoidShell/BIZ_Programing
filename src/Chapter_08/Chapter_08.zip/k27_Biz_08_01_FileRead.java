package Chapter_08;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class k27_Biz_08_01_FileRead {
    public static void main(String[] args) {
        try {
            // File 클래스
            File f = new File("aaa.txt ");
            FileWriter fw = new FileWriter(f);

            fw.write("안녕 파일\n");

            fw.write("hello 헬로\n");
            fw.close();

            FileReader fr = new FileReader(f);

            int n = -1;

            char[] ch;

            while (true) {
                ch = new char[100];
                n = fr.read(ch);
                if (n == -1)
                    break;
                for (int i = 0; i < n; i++) {
                    System.out.printf("%c", ch[i]);
                }
            }

            fr.close();
            System.out.printf("\nFILE READ END");
        } catch (Exception e) {
            System.out.printf("나 에러[%s]\n", e);
        }
    }
}