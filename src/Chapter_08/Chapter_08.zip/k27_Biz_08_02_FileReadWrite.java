package Chapter_08;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class k27_Biz_08_02_FileReadWrite {
    public static void FileWrite() throws IOException {

        File f = new File("aaa.txt ");
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));

        bw.write("안녕 파일 ");
        bw.newLine();
        bw.write("hello 헬로");
        bw.newLine();

        bw.close();
    }

    public static void FileRead() throws IOException {
        File f = new File("aaa.txt ");
        BufferedReader br = new BufferedReader(new FileReader(f));

        String readtxt;

        while ((readtxt = br.readLine()) != null) {
            System.out.printf("%s\n", readtxt);
        }
        br.close();
    }

    public static void main(String[] args) throws IOException {
        FileWrite();
        FileRead();
    }
}

