package Chapter_08;

import java.io.*;
import java.util.ArrayList;

public class k27_Biz_08_03_SeparateFile {
    public static final int WIFI_FIELD_NUM = 5;

    public static class Telecom {
        private String field;
        private boolean skt;
        private boolean kt;
        private boolean lgu;

        public Telecom(String field) {
            this.field = field;
        }

        public boolean isSkt() {
            return skt;
        }

        public void setSkt(boolean skt) {
            this.skt = skt;
        }

        public boolean isKt() {
            return kt;
        }

        public void setKt(boolean kt) {
            this.kt = kt;
        }

        public boolean isLgu() {
            return lgu;
        }

        public void setLgu(boolean lgu) {
            this.lgu = lgu;
        }

        public static void selectTelecom(ArrayList<Telecom> telecoms, String field, int LineCut) {
            String replaceField;
            replaceField = field.replaceAll("[㈜]|[+]|[\"]", "");
            String[] splitField = replaceField.split("[,]|[-]|[(]|[)]|[/]");

            for (int i = 0; i < splitField.length; i++) {
                if (splitField[i].trim().startsWith("S") || splitField[i].trim().startsWith("s")) {
                    telecoms.get(LineCut).setSkt(true);
                } else if (splitField[i].trim().startsWith("K") || splitField[i].trim().startsWith("케")) {
                    telecoms.get(LineCut).setKt(true);
                } else if (splitField[i].trim().startsWith("L") || splitField[i].trim().startsWith("U") || splitField[i].trim().startsWith("엘")) {
                    telecoms.get(LineCut).setLgu(true);
                } else if (splitField[i].trim().matches("^[가-힣\\s]*$") && !splitField[i].trim().startsWith("주")
                        && !splitField[i].startsWith(" ") || splitField[i].matches("\\u00A0") || splitField[i].startsWith("I")) {
                    System.out.printf("알 수 없는 통신사[%d번째항목][%s]***\n", LineCut + 1, splitField[i].trim());
                    // 아래는 교안처럼 출력하기
                    //System.out.printf("알 수 없는 통신사[%d번째항목][%s]***\n", LineCut + 1, field);
                }
            }
        }

        public static void writeFile(
                BufferedWriter sktBw, BufferedWriter ktBw, BufferedWriter lguBw, ArrayList<Telecom> telecoms, String[] field, int LineCut)
                throws IOException {

            if (telecoms.get(LineCut).isSkt()) {
                field[5] = "SKT";
                sktBw.write(writeLine(field));
                sktBw.newLine();
            }
            if (telecoms.get(LineCut).isKt()) {
                field[5] = "KT";
                ktBw.write(writeLine(field));
                ktBw.newLine();
            }
            if (telecoms.get(LineCut).isLgu()) {
                field[5] = "LGU";
                lguBw.write(writeLine(field));
                lguBw.newLine();
            }
        }

        public static String writeLine(String[] field) {
            StringBuilder stringBuilder = new StringBuilder();

            for (int i = 0; i < field.length; i++) {
                if (i < field.length - 1) {
                    stringBuilder.append(field[i]).append("\t");
                } else {
                    stringBuilder.append(field[i]);
                }
            }
            return stringBuilder.toString();
        }

        public static void main(String[] args) throws IOException {
            FileInputStream fis = new FileInputStream("전국무료와이파이표준데이터.txt");
            InputStreamReader is = new InputStreamReader(fis, "EUC-KR");
            BufferedReader br = new BufferedReader(is);

            BufferedWriter sktBw = new BufferedWriter(new OutputStreamWriter
                    (new FileOutputStream("전국무료와이파이표준데이터_SKT.txt")));
            BufferedWriter ktBw = new BufferedWriter(new OutputStreamWriter
                    (new FileOutputStream("전국무료와이파이표준데이터_KT.txt")));
            BufferedWriter lguBw = new BufferedWriter(new OutputStreamWriter
                    (new FileOutputStream("전국무료와이파이표준데이터_LGU.txt")));

            String readtxt;

            if ((readtxt = br.readLine()) == null) {
                System.out.printf("빈 파일입니다\n");
                return;
            }

            sktBw.write(readtxt);
            sktBw.newLine();
            ktBw.write(readtxt);
            ktBw.newLine();
            lguBw.write(readtxt);
            lguBw.newLine();

            int LineCut = 0;

            ArrayList<Telecom> telecoms = new ArrayList<>();

            while ((readtxt = br.readLine()) != null) {
                String[] field = readtxt.split("\t");
                telecoms.add(new Telecom(field[WIFI_FIELD_NUM]));
                selectTelecom(telecoms, field[WIFI_FIELD_NUM], LineCut);
                writeFile(sktBw, ktBw, lguBw, telecoms, field, LineCut);
                LineCut++;
            }
            br.close();
            sktBw.close();
            ktBw.close();
            lguBw.close();
        }
    }
}