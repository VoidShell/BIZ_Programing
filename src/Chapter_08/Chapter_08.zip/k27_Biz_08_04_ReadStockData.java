package Chapter_08;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class k27_Biz_08_04_ReadStockData {
    public static void main(String[] args) throws IOException, ParseException {
        SimpleDateFormat sdfYMD = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sdfMS = new SimpleDateFormat("SSS");
        SimpleDateFormat sdfHMS = new SimpleDateFormat("HH:mm:ss");

        File f = new File("THTSKS010H00.dat");
        BufferedReader br = new BufferedReader(new FileReader(f));

        Calendar startTime = Calendar.getInstance();
        System.out.printf("Program Start\n");
        System.out.println(sdfYMD.format(startTime.getTime()));
        System.out.printf("\n");

        String readtxt;
        int LineCnt = 0;
        int n = -1;
        StringBuffer s = new StringBuffer();

        while(true) {
            char [] ch = new char[1000];
            n = br.read(ch);
            if(n == -1) break;
            for(char c : ch) {
                if(c =='\n') {
                    System.out.printf("[%s]***\n", s.toString());
                    s.delete(0,  s.length());
                } else {
                    s.append(c);
                }
            }
            LineCnt++;
        }

        System.out.printf("[%s]***\n", s.toString());
        br.close();
        System.out.printf("Program End\n");
        Calendar endTime = Calendar.getInstance();
        System.out.println(sdfYMD.format(endTime.getTime()));
        System.out.printf("\n");

        long time = endTime.getTimeInMillis() - startTime.getTimeInMillis();
        Date procTime = sdfMS.parse(String.valueOf(time));

        System.out.printf("Processing Time: %s\n", sdfHMS.format(procTime));
    }
}
